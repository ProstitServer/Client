----------------[Terms of use]---------------------

You may use everything we made in this pack using NegativeSpaces4 under Creative Commons Attribution 4.0 International terms.
If you use anything out of this pack that includes the NegativeSpaces4 resource pack, you need to credit AmberW/AmberWat.

Using anything aside from the NegativeSpaces4 pack, you need to ask us for permissions.
This includes the icons themselves and the Unicode system for only the icons.
No one is allowed to redistribute Icons as is without written permission.

You can:
Use it as a template to understand and make something your own
Create an addon for it
Change/add to the pack to the point they are distinguishable on their own.

----------------[Credit]---------------------------


--Pack Creators:--

mr_ch0c0late (Creator and Idea)

Curse Forge: 		https://www.curseforge.com/members/mr_ch0c0late1
Planet Minecraft: 	https://www.planetminecraft.com/member/mr_ch0c0late1/
Twitter: 			https://twitter.com/mr_ch0c0late1



Zartrix 

Curse Forge:		https://www.curseforge.com/members/zartrix
Reddit: 			https://www.reddit.com/user/Zartrix



AmberW/AmberWat

GitHub:			https://github.com/AmberWat
Discord(Minecraft Commands)